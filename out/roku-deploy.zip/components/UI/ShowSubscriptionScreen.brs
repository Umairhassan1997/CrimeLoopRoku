sub ShowSubscriptionScreen()
    m.SubscriptionScreen = CreateObject("roSGNode", "SubscriptionScreen")
    m.SubscriptionScreen.ObserveField("btnMonthlySelect", "onbtnMonthlySelect")
    m.SubscriptionScreen.ObserveField("btnYearlySelect", "onbtnYearlySelect")
    ShowScreen(m.SubscriptionScreen)

    if m.global.analytics <> invalid
        m.global.analytics.callFunc("logEvent", "subscription_screen_opened", {
            "screen_name": "SubscriptionScreen"
        })
    end if
end sub

sub onbtnMonthlySelect()
    m.top.isSubYearly = false
    StartSubscription()
end sub

sub onbtnYearlySelect()
    m.top.isSubYearly = true
    StartSubscription()
end sub

function StartSubscription()
    if m.top.isSubYearly = false
        m.order_title = "CrimeLoop Monthly"
        m.order_identifier = "CrimeLoopMonthly"
        m.order_price = "4.99"
    else
        m.order_title = "CrimeLoop Yearly"
        m.order_identifier = "CrimeLoopYearly"
        m.order_price = "29.99"
    end if

    m.global.AddField("channelStore", "node", false)
    m.global.channelStore = CreateObject("roSGNode", "ChannelStore")
    m.global.channelStore.observeField("requestPartnerOrderStatus", "requestPartnerOrderStatusChanged")
    ValidateSubscription()
end function

sub ValidateSubscription()
    m.orderInfo = CreateObject("roSGNode", "ContentNode")
    m.orderInfo.priceDisplay = m.order_price
    m.orderInfo.price = m.order_price
    m.orderInfo.addField("code", "string", false)
    m.orderInfo.code = m.order_identifier

    m.global.channelStore.requestPartnerOrder = m.orderInfo
    m.global.channelStore.command = "requestPartnerOrder"
end sub

sub requestPartnerOrderStatusChanged()
    m.global.channelStore.command = "getUserData"
    m.global.channelStore.observeField("userData", "onGetUserData")
end sub

sub onGetUserData()
    if m.global.channelStore.userData <> invalid
        m.global.channelStore.command = "getPurchases"
        m.global.channelStore.ObserveField("purchases", "onGetPurchases")
    end if
end sub

sub onGetPurchases(event as object)
    m.global.channelStore.UnobserveField("purchases")
    purchases = event.GetData()

    if purchases <> invalid and purchases.GetChildCount() > 0
        allPurchases = purchases.GetChildren(-1, 0)
        datetime = CreateObject("roDateTime")
        utimeNow = datetime.AsSeconds()

        for each purchase in allPurchases
            if purchase.code = m.order_identifier
                datetime.FromISO8601String(purchase.expirationDate)
                utimeExpire = datetime.AsSeconds()
                m.expireTime = utimeExpire.ToStr()

                if utimeExpire > utimeNow
                    setUserData(m.expireTime)
                    m.top.isSubscribed = true
                    m.screenStack = []
                    ShowHomeScreen()
                    dialogCheckProducts = CreateObject("roSGNode", "StandardMessageDialog")
                    dialogCheckProducts.title = "Subscribed Successfully. Please Continue Using this App"
                    m.top.dialog = dialogCheckProducts
                    return
                end if
            end if
        end for
    end if

    dialogCheckProducts = CreateObject("roSGNode", "StandardMessageDialog")
    dialogCheckProducts.title = "Please Wait while we fetch details"
    m.top.dialog = dialogCheckProducts

    m.global.channelStore.command = "getCatalog"
    m.global.channelStore.ObserveField("catalog", "OnGetCatalog")
end sub

sub OnGetCatalog(event as object)
    m.global.channelStore.UnobserveField("catalog")
    catalog = event.GetData()

    if m.top.dialog <> invalid
        m.top.dialog.close = true
    else
        return
    end if

    if catalog = invalid or catalog.GetChildCount() = 0
        return
    end if

    m.activeCatalogItems = []
    for each product in catalog.GetChildren(-1, 0)
        if product.code = m.order_identifier
            m.activeCatalogItems.Push({
                code: product.code,
                name: product.name
            })
        end if
    end for

    if m.activeCatalogItems.Count() > 0
        DoSubscriptionOrder()
    end if
end sub

sub DoSubscriptionOrder()
    order = CreateObject("roSGNode", "ContentNode")
    product = order.CreateChild("ContentNode")
    product.AddFields({ code: m.order_identifier, name: m.order_title, qty: 1 })

    m.global.channelStore.order = order
    m.global.channelStore.command = "doOrder"
    m.global.channelStore.ObserveField("orderStatus", "OnOrderStatus")
end sub

sub OnOrderStatus(event as object)
    orderStatus = event.GetData()

    if orderStatus <> invalid and orderStatus.status = 1
        if m.global.analytics <> invalid
            m.global.analytics.callFunc("logEvent", "subscription_successful", {
                "screen_name": "SubscriptionScreen"
            })
        end if
        onGetUserData()
    end if

    m.global.channelStore.UnobserveField("orderStatus")
end sub

function setUserData(expireTime as string)
    sec = CreateObject("roRegistrySection", m.global.appName + "UserSubscriptionData")
    sec.Write(m.global.appName + "subscription_expire_time", expireTime)
    sec.Flush()
end function
