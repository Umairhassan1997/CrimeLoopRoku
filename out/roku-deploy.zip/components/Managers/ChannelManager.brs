' ChannelManager — static live TV channel list and index helpers

function GetLiveChannelList() as Object
    return [
        {
            id: "1"
            title: "GSN Cinevault Westerns"
            streamUrl: "https://gsn-cinevault-westerns-2-us.roku.wurl.tv/playlist.m3u8"
            logo: "pkg:/images/HeroItem.png"
        },
        {
            id: "2"
            title: "Cineverse 899"
            streamUrl: "https://linear-899.frequency.stream/dist/cineverse/899/hls/master/playlist.m3u8"
            logo: "pkg:/images/HeroItem.png"
        },
        {
            id: "3"
            title: "Amogonetworx Artflix"
            streamUrl: "https://amogonetworx-artflix-1-nl.samsung.wurl.tv/playlist.m3u8"
            logo: "pkg:/images/HeroItem.png"
        },
        {
            id: "4"
            title: "Cineverse 1080"
            streamUrl: "https://linear-1080.frequency.stream/dist/cineverse/1080/hls/master/playlist.m3u8"
            logo: "pkg:/images/HeroItem.png"
        }
    ]
end function

function GetLiveChannelCount() as Integer
    return GetLiveChannelList().Count()
end function

function GetLiveChannel(index as Integer) as Object
    channels = GetLiveChannelList()
    if index < 0 or index >= channels.Count()
        return invalid
    end if
    return channels[index]
end function

function GetNextChannelIndex(currentIndex as Integer) as Integer
    count = GetLiveChannelCount()
    if count = 0
        return 0
    end if
    return (currentIndex + 1) mod count
end function

function GetPreviousChannelIndex(currentIndex as Integer) as Integer
    count = GetLiveChannelCount()
    if count = 0
        return 0
    end if
    idx = currentIndex - 1
    if idx < 0
        idx = count - 1
    end if
    return idx
end function
