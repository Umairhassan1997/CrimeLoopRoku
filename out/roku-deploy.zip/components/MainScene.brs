sub init()
    m.global.AddField("videoDurationLimit", "integer", false)
    m.global.AddField("audioDurationLimit", "integer", false)
    m.global.audioDurationLimit = 240

    m.appTimer = m.top.findNode("appTimer")
    m.appTimer.observeField("fire", "onAppTimerFire")

    m.global.AddField("RAT", "boolean", false)
    m.global.RAT = true
    m.global.AddField("appDuration", "integer", false)
    m.global.AddField("appName", "string", false)
    m.global.appName = "CrimeLoop"

    m.global.observeField("appDuration", "checkAppDuration")

    m.global.videoDurationLimit = 240000000
    m.global.AddField("duration", "integer", false)
    m.global.AddField("videoArray", "assocarray", false)
    m.global.videoArray = {}
    m.global.duration = (getCurrentDuration()).toInt()
    m.global.observeField("duration", "checkCurrentDuration")

    m.top.isSubscribed = false
    m.top.isSubYearly = false

    InitScreenStack()
    SetupGoogleAnalytics4()

    reg = CreateObject("roRegistrySection", m.global.appName)

    if reg.Exists("optionSelected") = false
        ShowTrialScreen()
    else
        VerifySubscription()
        ShowHomeScreen()
    end if
end sub

sub SetupGoogleAnalytics4()
    m.global.AddField("analytics", "node", false)
    m.global.analytics = CreateObject("roSGNode", "GoogleAnalytics")
    m.global.analytics.callFunc("initialize", {
        measurementId: "z"
        appName: "CrimeLoop"
        docLocation: "https://www.google.com"
        customArgs: {}
    })
    m.global.analytics.callFunc("start")
end sub

sub checkCurrentDuration()
    if m.global.duration >= m.global.videoDurationLimit and m.top.isSubscribed = false
        m.screenStack = []
        ShowSubscriptionScreen()
        m.global.UnobserveField("duration")
    end if
end sub

sub ResetScreen()
    m.screenStack = []
    ShowHomeScreen()
end sub

function getCurrentDuration()
    today = GetTodayShortDate()
    sec = CreateObject("roRegistrySection", "SR" + today)
    if sec.Exists("duration")
        currentDuration = sec.Read("duration")
        return currentDuration
    else
        return "1"
    end if
end function

sub startCountDown()
    m.appTimer.control = "start"
    m.global.observeField("RAT", "restartAppTimer")
end sub

sub checkAppDuration()
    if m.top.isSubscribed = false
        if m.global.appDuration >= m.global.audioDurationLimit
            if m.screenStack <> invalid and m.screenStack.Count() > 0
                currentScreen = m.screenStack[m.screenStack.Count() - 1]
                if m.HomeScreen <> invalid and currentScreen.IsSameNode(m.HomeScreen)
                    m.HomeScreen.isTrialExpired = true
                else if m.SettingScreen <> invalid and currentScreen.IsSameNode(m.SettingScreen)
                    m.SettingScreen.isTrialExpired = true
                else if m.FavoriteScreen <> invalid and currentScreen.IsSameNode(m.FavoriteScreen)
                    m.FavoriteScreen.isTrialExpired = true
                else if m.SearchScreen <> invalid and currentScreen.IsSameNode(m.SearchScreen)
                    m.SearchScreen.isTrialExpired = true
                end if
            end if
            m.global.UnobserveField("appDuration")
        end if
    end if
end sub

sub restartAppTimer()
    if m.global.RAT
        m.appTimer.control = "start"
    else
        m.appTimer.control = "stop"
    end if
end sub

sub onAppTimerFire()
    today = GetTodayShortDate()
    sec = CreateObject("roRegistrySection", "CrimeLoop" + today)

    if sec.Exists("appDuration")
        oldAppDur = sec.Read("appDuration").toInt()
        newAppDur = oldAppDur + 1
        m.global.appDuration = newAppDur
        sec.Write("appDuration", newAppDur.toStr())
        sec.Flush()
    else
        m.global.appDuration = 1
        sec.Write("appDuration", "1")
        sec.Flush()
    end if
end sub

function GetTodayShortDate() as String
    dt = CreateObject("roDateTime")
    dt.ToLocalTime()

    year = dt.GetYear().ToStr()
    month = dt.GetMonth().ToStr()
    day = dt.GetDayOfMonth().ToStr()

    if month.Len() = 1 then month = "0" + month
    if day.Len() = 1 then day = "0" + day

    return year + month + day
end function

sub setCurrentDuration()
    today = GetTodayShortDate()
    sec = CreateObject("roRegistrySection", "SR" + today)
    if sec.Exists("duration")
        currentDuration = sec.Read("duration")
        updatedDuration = currentDuration.toInt() + 1
        m.global.duration = updatedDuration
        sec.Write("duration", updatedDuration.toStr())
        sec.Flush()
    else
        sec.Write("duration", "1")
        sec.Flush()
        m.global.duration = 1
    end if
end sub

function OnKeyEvent(key as string, press as boolean) as boolean
    result = false
    if press
        if key = "back"
            if m.screenStack <> invalid
                numberOfScreens = m.screenStack.Count()
                if numberOfScreens > 1
                    CloseScreen(invalid)
                    result = true
                end if
            end if
        end if
    end if
    return result
end function
